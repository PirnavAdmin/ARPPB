import { createContext, useContext, useMemo, useState, useCallback, useEffect } from 'react';
import {
  initialProfile,
  initialCrops,
  initialMarketPrices,
  initialSales,
  initialPurchases,
  initialStockRecords,
  initialOTPRequests,
  initialLedgerEntries,
  initialNotifications,
} from '../data/farmerData';
import {
  generateTransactionId,
  generateOTP,
  calculateExpectedPaymentDate,
  formatCurrency,
} from '../utils/farmerHelpers';

const FarmerContext = createContext(null);

export const farmerNavItems = [
  { key: 'dashboard', label: 'Dashboard', icon: 'dashboard' },
  { key: 'crops', label: 'My Crops', icon: 'crops' },
  { key: 'prices', label: 'Daily Market Prices', icon: 'prices' },
  { key: 'sell', label: 'Sell Products', icon: 'sell' },
  { key: 'sales', label: 'My Sales', icon: 'sales' },
  { key: 'purchases', label: 'Purchase History', icon: 'purchases' },
  { key: 'stock', label: 'Stock Management', icon: 'stock' },
  { key: 'otp', label: 'OTP Confirmations', icon: 'otp', hasBadge: true },
  { key: 'ledger', label: 'My Ledger', icon: 'ledger' },
  { key: 'notifications', label: 'Notifications', icon: 'bell', hasBadge: true },
  { key: 'profile', label: 'My Profile', icon: 'profile' },
];

export function FarmerProvider({ children }) {
  const [activePage, setActivePage] = useState('dashboard');
  const [pageParam, setPageParam] = useState(null); // optional parameter for navigation
  const [searchQuery, setSearchQuery] = useState('');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileDrawerOpen, setIsMobileDrawerOpen] = useState(false);

  // Core Data States
  const [profile, setProfile] = useState(initialProfile);
  const [crops, setCrops] = useState(initialCrops);
  const [marketPrices, setMarketPrices] = useState(initialMarketPrices);
  const [sales, setSales] = useState(initialSales);
  const [purchases, setPurchases] = useState(initialPurchases);
  const [stockRecords, setStockRecords] = useState(initialStockRecords);
  const [otpRequests, setOtpRequests] = useState(initialOTPRequests);
  const [ledger, setLedger] = useState(initialLedgerEntries);
  const [notifications, setNotifications] = useState(initialNotifications);

  // Global Modals
  const [selectedTransaction, setSelectedTransaction] = useState(null);
  const [activeOtpRequest, setActiveOtpRequest] = useState(null);
  const [toast, setToast] = useState(null);

  const showToast = useCallback((message, type = 'success', duration = 5000) => {
    const id = Date.now();
    setToast({ id, message, type });
    setTimeout(() => {
      setToast((curr) => (curr && curr.id === id ? null : curr));
    }, duration);
  }, []);

  const hideToast = useCallback(() => {
    setToast(null);
  }, []);

  // Unread counts
  const unreadNotificationsCount = useMemo(
    () => notifications.filter((n) => !n.read).length,
    [notifications]
  );

  const pendingOtpCount = useMemo(
    () => otpRequests.filter((o) => o.otpStatus === 'Pending').length,
    [otpRequests]
  );

  // Page navigation helper
  const navigateTo = useCallback((pageKey, param = null) => {
    setActivePage(pageKey);
    setPageParam(param);
    setIsMobileDrawerOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  // Notifications Actions
  const markNotificationAsRead = useCallback((id) => {
    setNotifications((prev) =>
      prev.map((item) => (item.id === id ? { ...item, read: true } : item))
    );
  }, []);

  const markAllNotificationsAsRead = useCallback(() => {
    setNotifications((prev) => prev.map((item) => ({ ...item, read: true })));
    showToast('All notifications marked as read', 'info', 3000);
  }, [showToast]);

  // Profile Action
  const updateProfile = useCallback((updated) => {
    setProfile((prev) => ({ ...prev, ...updated }));
    showToast('Profile updated successfully!', 'success');
  }, [showToast]);

  // Crop CRUD Actions
  const addCrop = useCallback((newCropData) => {
    const newId = `CROP-00${Date.now().toString().slice(-4)}`;
    const crop = {
      id: newId,
      availableQuantity: Number(newCropData.harvestedQuantity || newCropData.availableQuantity || 0),
      soldQuantity: 0,
      reservedQuantity: 0,
      harvestedQuantity: Number(newCropData.harvestedQuantity || newCropData.availableQuantity || 0),
      status: 'Ready to Sell',
      color: '#237A45',
      ...newCropData,
    };

    setCrops((prev) => [crop, ...prev]);

    // Also create corresponding stock record
    setStockRecords((prev) => [
      {
        id: `STK-${newId.slice(-3)}`,
        cropName: crop.name,
        variety: crop.variety || 'Standard',
        openingStock: crop.availableQuantity,
        harvestedQuantity: crop.availableQuantity,
        soldQuantity: 0,
        reservedQuantity: 0,
        availableQuantity: crop.availableQuantity,
        unit: crop.unit || 'qtl',
        lastUpdated: new Date().toISOString().split('T')[0],
        status: crop.availableQuantity > 50 ? 'Normal' : 'Low Stock',
        storageLocation: `Reddy Farm Warehouse Bay-${(prev.length % 3) + 1}`,
      },
      ...prev,
    ]);

    showToast(`Crop "${crop.name}" registered successfully!`, 'success');
  }, [showToast]);

  const updateCrop = useCallback((id, updatedFields) => {
    setCrops((prev) =>
      prev.map((c) => (c.id === id ? { ...c, ...updatedFields } : c))
    );
    showToast('Crop information updated.', 'success');
  }, [showToast]);

  const deleteCrop = useCallback((id) => {
    const crop = crops.find((c) => c.id === id);
    if (!crop) return;
    // Check if there are active sales
    const hasActiveSales = sales.some(
      (s) => s.cropName.toLowerCase() === crop.name.toLowerCase() && s.transactionStatus === 'Pending Confirmation'
    );
    if (hasActiveSales) {
      showToast('Cannot delete crop with pending transactions.', 'error');
      return;
    }
    setCrops((prev) => prev.filter((c) => c.id !== id));
    setStockRecords((prev) => prev.filter((s) => s.cropName.toLowerCase() !== crop.name.toLowerCase()));
    showToast(`Crop "${crop.name}" removed from inventory.`, 'info');
  }, [crops, sales, showToast]);

  // Adjust Stock / Harvest
  const addHarvestStock = useCallback((cropName, additionalQty, unit = 'qtl') => {
    const qty = Number(additionalQty);
    if (isNaN(qty) || qty <= 0) return;

    setCrops((prev) =>
      prev.map((c) => {
        if (c.name.toLowerCase() === cropName.toLowerCase()) {
          const newHarvested = c.harvestedQuantity + qty;
          const newAvailable = c.availableQuantity + qty;
          return {
            ...c,
            harvestedQuantity: newHarvested,
            availableQuantity: newAvailable,
            status: newAvailable < 50 ? 'Low Stock' : 'Ready to Sell',
          };
        }
        return c;
      })
    );

    setStockRecords((prev) =>
      prev.map((s) => {
        if (s.cropName.toLowerCase() === cropName.toLowerCase()) {
          const newHarvested = s.harvestedQuantity + qty;
          const newAvailable = s.availableQuantity + qty;
          return {
            ...s,
            harvestedQuantity: newHarvested,
            availableQuantity: newAvailable,
            lastUpdated: new Date().toISOString().split('T')[0],
            status: newAvailable < 50 ? 'Low Stock' : 'Normal',
          };
        }
        return s;
      })
    );

    // Add notification
    setNotifications((prev) => [
      {
        id: `NOTIF-${Date.now()}`,
        title: 'Stock Updated',
        detail: `Added ${qty} ${unit} harvested yield to ${cropName} stock. Available balance updated.`,
        time: 'Just now',
        timestamp: new Date().toISOString(),
        type: 'info',
        category: 'stock',
        read: false,
        targetPage: 'stock',
      },
      ...prev,
    ]);

    showToast(`Harvest of ${qty} ${unit} added to ${cropName} successfully!`, 'success');
  }, [showToast]);

  // Sell Products: Create Sale Transaction
  const createSale = useCallback((saleForm) => {
    const crop = crops.find((c) => c.name.toLowerCase() === saleForm.cropName.toLowerCase());
    const qty = Number(saleForm.sellingQuantity);
    const rate = Number(saleForm.rate);
    const total = qty * rate;

    if (!crop) {
      showToast('Selected crop not found.', 'error');
      return null;
    }

    if (qty <= 0) {
      showToast('Selling quantity must be greater than zero.', 'error');
      return null;
    }

    if (qty > crop.availableQuantity) {
      showToast(`Selling quantity exceeds available stock (${crop.availableQuantity} ${crop.unit})`, 'error');
      return null;
    }

    const txId = generateTransactionId();
    const otpCode = generateOTP();
    const today = new Date().toISOString().split('T')[0];
    const expectedPayDate = calculateExpectedPaymentDate(new Date(), 3);

    // 1. Create Transaction (Pending Confirmation)
    const newTransaction = {
      id: txId,
      date: today,
      cropName: crop.name,
      buyerName: saleForm.buyerName.trim(),
      buyerCategory: saleForm.buyerCategory,
      buyerMobile: saleForm.buyerMobile.trim(),
      quantity: qty,
      unit: crop.unit,
      rate: rate,
      totalAmount: total,
      transactionStatus: 'Pending Confirmation',
      otpStatus: 'Pending',
      expectedPaymentDate: expectedPayDate,
      paymentStatus: 'Payment Expected',
      pickupLocation: saleForm.pickupLocation || `${profile.farmName}, ${profile.village}`,
      notes: saleForm.notes || 'Sale initiated by farmer. Pending OTP confirmation from receiving party.',
      qualityGrade: saleForm.qualityGrade || crop.qualityGrade,
    };

    setSales((prev) => [newTransaction, ...prev]);

    // 2. Mark stock as reserved until OTP confirmed
    setCrops((prev) =>
      prev.map((c) => {
        if (c.name.toLowerCase() === crop.name.toLowerCase()) {
          return {
            ...c,
            reservedQuantity: (c.reservedQuantity || 0) + qty,
            availableQuantity: c.availableQuantity - qty,
          };
        }
        return c;
      })
    );

    setStockRecords((prev) =>
      prev.map((s) => {
        if (s.cropName.toLowerCase() === crop.name.toLowerCase()) {
          return {
            ...s,
            reservedQuantity: (s.reservedQuantity || 0) + qty,
            availableQuantity: s.availableQuantity - qty,
            lastUpdated: today,
          };
        }
        return s;
      })
    );

    // 3. Create OTP Confirmation Request
    const newOtpRequest = {
      id: `OTP-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`,
      transactionId: txId,
      buyerName: newTransaction.buyerName,
      buyerCategory: newTransaction.buyerCategory,
      buyerMobile: newTransaction.buyerMobile,
      crop: crop.name,
      quantity: qty,
      unit: crop.unit,
      rate: rate,
      totalAmount: total,
      requestDate: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ' Today',
      otpStatus: 'Pending',
      otpCode: otpCode, // For demo purposes, buyer receives this 6-digit code
      expiresInMinutes: 10,
      attemptsLeft: 3,
      direction: 'farmer_initiated',
    };

    setOtpRequests((prev) => [newOtpRequest, ...prev]);

    // 4. Create Notification
    setNotifications((prev) => [
      {
        id: `NOTIF-${Date.now()}`,
        title: 'New Sale Initiated',
        detail: `Sale of ${qty} ${crop.unit} ${crop.name} to ${newTransaction.buyerName} (${formatCurrency(total)}) created. OTP sent to buyer mobile. Stock reserved.`,
        time: 'Just now',
        timestamp: new Date().toISOString(),
        type: 'warning',
        category: 'otp',
        read: false,
        targetPage: 'otp',
        targetId: txId,
      },
      ...prev,
    ]);

    showToast(
      `Sale ${txId} created! 6-digit OTP (${otpCode}) sent to ${newTransaction.buyerName}. Stock will deduct upon confirmation.`,
      'info',
      8000
    );

    return { transaction: newTransaction, otpRequest: newOtpRequest };
  }, [crops, profile, showToast]);

  // Verify OTP Confirmation Action
  const verifyOTP = useCallback((otpId, enteredCode) => {
    const otpReq = otpRequests.find((o) => o.id === otpId);
    if (!otpReq) {
      showToast('OTP request not found.', 'error');
      return false;
    }

    if (otpReq.otpStatus !== 'Pending') {
      showToast(`This OTP request is already ${otpReq.otpStatus.toLowerCase()}.`, 'warning');
      return false;
    }

    if (otpReq.attemptsLeft <= 1 && enteredCode !== otpReq.otpCode) {
      // Mark as expired / failed
      setOtpRequests((prev) =>
        prev.map((o) => (o.id === otpId ? { ...o, otpStatus: 'Expired', attemptsLeft: 0 } : o))
      );
      showToast('Maximum verification attempts exceeded. OTP expired.', 'error');
      return false;
    }

    if (enteredCode !== otpReq.otpCode) {
      setOtpRequests((prev) =>
        prev.map((o) => (o.id === otpId ? { ...o, attemptsLeft: o.attemptsLeft - 1 } : o))
      );
      showToast(`Invalid OTP. ${otpReq.attemptsLeft - 1} attempt(s) remaining. (Demo OTP is ${otpReq.otpCode})`, 'error');
      return false;
    }

    // OTP IS VALID!
    // 1. Mark OTP as Confirmed
    setOtpRequests((prev) =>
      prev.map((o) => (o.id === otpId ? { ...o, otpStatus: 'Confirmed' } : o))
    );

    // 2. Mark Transaction as Confirmed
    const today = new Date().toISOString().split('T')[0];
    const expectedPayDate = calculateExpectedPaymentDate(new Date(), 3);

    setSales((prev) =>
      prev.map((s) => {
        if (s.id === otpReq.transactionId) {
          return {
            ...s,
            transactionStatus: 'Confirmed',
            otpStatus: 'Verified',
            expectedPaymentDate: expectedPayDate,
            paymentStatus: 'Payment Expected',
          };
        }
        return s;
      })
    );

    // 3. Update Farmer Stock: Move from reserved to sold!
    // If direction was received_request, stock was not reserved yet, so subtract from available directly.
    setCrops((prev) =>
      prev.map((c) => {
        if (c.name.toLowerCase() === otpReq.crop.toLowerCase()) {
          const wasReserved = otpReq.direction === 'farmer_initiated';
          return {
            ...c,
            soldQuantity: c.soldQuantity + otpReq.quantity,
            reservedQuantity: wasReserved ? Math.max(0, (c.reservedQuantity || 0) - otpReq.quantity) : c.reservedQuantity,
            availableQuantity: wasReserved ? c.availableQuantity : Math.max(0, c.availableQuantity - otpReq.quantity),
          };
        }
        return c;
      })
    );

    setStockRecords((prev) =>
      prev.map((s) => {
        if (s.cropName.toLowerCase() === otpReq.crop.toLowerCase()) {
          const wasReserved = otpReq.direction === 'farmer_initiated';
          return {
            ...s,
            soldQuantity: s.soldQuantity + otpReq.quantity,
            reservedQuantity: wasReserved ? Math.max(0, (s.reservedQuantity || 0) - otpReq.quantity) : s.reservedQuantity,
            availableQuantity: wasReserved ? s.availableQuantity : Math.max(0, s.availableQuantity - otpReq.quantity),
            lastUpdated: today,
          };
        }
        return s;
      })
    );

    // 4. Update Farmer Ledger: Add credit entry for the expected payment
    const lastBalance = ledger.length > 0 ? ledger[0].runningBalance : 0;
    const newBalance = lastBalance + otpReq.totalAmount;

    const newLedgerEntry = {
      id: `LED-${Date.now().toString().slice(-4)}`,
      date: today,
      transactionId: otpReq.transactionId,
      description: `Sale of ${otpReq.quantity} ${otpReq.unit} ${otpReq.crop} to ${otpReq.buyerName}`,
      partyName: otpReq.buyerName,
      partyCategory: otpReq.buyerCategory,
      debit: 0,
      credit: otpReq.totalAmount,
      runningBalance: newBalance,
      expectedPaymentDate: expectedPayDate,
      paymentStatus: 'Payment Expected',
    };

    setLedger((prev) => [newLedgerEntry, ...prev]);

    // 5. Add Notification
    setNotifications((prev) => [
      {
        id: `NOTIF-${Date.now()}`,
        title: 'Transaction Confirmed Successfully!',
        detail: `Your sale of ${otpReq.quantity} ${otpReq.unit} ${otpReq.crop} for ${formatCurrency(otpReq.totalAmount)} has been confirmed. Your payment is expected within 3 working days (${expectedPayDate}).`,
        time: 'Just now',
        timestamp: new Date().toISOString(),
        type: 'success',
        category: 'sales',
        read: false,
        targetPage: 'sales',
        targetId: otpReq.transactionId,
      },
      ...prev,
    ]);

    showToast(
      `Transaction Confirmed Successfully! Your payment is expected within 3 working days.`,
      'success',
      7000
    );

    setActiveOtpRequest(null);
    return true;
  }, [otpRequests, ledger, showToast]);

  // Reject OTP Transaction Action
  const rejectOTP = useCallback((otpId, reason = 'Transaction rejected by user') => {
    const otpReq = otpRequests.find((o) => o.id === otpId);
    if (!otpReq) return;

    // 1. Mark OTP as Rejected
    setOtpRequests((prev) =>
      prev.map((o) => (o.id === otpId ? { ...o, otpStatus: 'Rejected' } : o))
    );

    // 2. Mark Transaction as Rejected
    setSales((prev) =>
      prev.map((s) => {
        if (s.id === otpReq.transactionId) {
          return {
            ...s,
            transactionStatus: 'Rejected',
            otpStatus: 'Rejected',
            notes: `${s.notes} [Rejected: ${reason}]`,
          };
        }
        return s;
      })
    );

    // 3. Release reserved stock back to available
    if (otpReq.direction === 'farmer_initiated') {
      setCrops((prev) =>
        prev.map((c) => {
          if (c.name.toLowerCase() === otpReq.crop.toLowerCase()) {
            return {
              ...c,
              reservedQuantity: Math.max(0, (c.reservedQuantity || 0) - otpReq.quantity),
              availableQuantity: c.availableQuantity + otpReq.quantity,
            };
          }
          return c;
        })
      );

      setStockRecords((prev) =>
        prev.map((s) => {
          if (s.cropName.toLowerCase() === otpReq.crop.toLowerCase()) {
            return {
              ...s,
              reservedQuantity: Math.max(0, (s.reservedQuantity || 0) - otpReq.quantity),
              availableQuantity: s.availableQuantity + otpReq.quantity,
            };
          }
          return s;
        })
      );
    }

    // 4. Notification
    setNotifications((prev) => [
      {
        id: `NOTIF-${Date.now()}`,
        title: 'Transaction Rejected',
        detail: `Transaction ${otpReq.transactionId} for ${otpReq.crop} was rejected. Reserved stock restored to inventory.`,
        time: 'Just now',
        timestamp: new Date().toISOString(),
        type: 'danger',
        category: 'otp',
        read: false,
        targetPage: 'otp',
      },
      ...prev,
    ]);

    showToast(`Transaction ${otpReq.transactionId} rejected. Reserved stock has been released.`, 'info');
    setActiveOtpRequest(null);
  }, [otpRequests, showToast]);

  // Resend OTP Action
  const resendOTP = useCallback((otpId) => {
    const newCode = generateOTP();
    setOtpRequests((prev) =>
      prev.map((o) =>
        o.id === otpId
          ? {
              ...o,
              otpCode: newCode,
              expiresInMinutes: 10,
              attemptsLeft: 3,
            }
          : o
      )
    );
    showToast(`New OTP sent successfully! Demo OTP: ${newCode}`, 'info', 6000);
  }, [showToast]);

  // Add Purchase Action
  const addPurchase = useCallback((purchaseData) => {
    const newId = `PUR-AGRI-2026-0${Date.now().toString().slice(-3)}`;
    const total = Number(purchaseData.quantity) * Number(purchaseData.price);
    const purchase = {
      id: newId,
      date: new Date().toISOString().split('T')[0],
      totalAmount: total,
      status: 'Received',
      ...purchaseData,
    };

    setPurchases((prev) => [purchase, ...prev]);

    // Add debit entry to ledger
    const lastBalance = ledger.length > 0 ? ledger[0].runningBalance : 0;
    const newBalance = lastBalance - total;

    setLedger((prev) => [
      {
        id: `LED-${Date.now().toString().slice(-4)}`,
        date: purchase.date,
        transactionId: newId,
        description: `Purchase: ${purchase.quantity} ${purchase.unit || ''} ${purchase.productName}`,
        partyName: purchase.supplierName,
        partyCategory: 'Supplier',
        debit: total,
        credit: 0,
        runningBalance: newBalance,
        expectedPaymentDate: purchase.expectedPaymentDate || purchase.date,
        paymentStatus: 'Settled',
      },
      ...prev,
    ]);

    showToast(`Purchase ${newId} recorded in history and ledger.`, 'success');
  }, [ledger, showToast]);

  // Manual payment status update in ledger (authorized manual process only!)
  const updatePaymentStatus = useCallback((ledgerId, newStatus) => {
    setLedger((prev) =>
      prev.map((entry) => {
        if (entry.id === ledgerId) {
          return { ...entry, paymentStatus: newStatus };
        }
        return entry;
      })
    );

    // Also update corresponding sales transaction if linked
    const ledgerEntry = ledger.find((e) => e.id === ledgerId);
    if (ledgerEntry && ledgerEntry.transactionId) {
      setSales((prev) =>
        prev.map((s) => {
          if (s.id === ledgerEntry.transactionId) {
            return { ...s, paymentStatus: newStatus };
          }
          return s;
        })
      );
    }

    showToast(`Payment status updated to "${newStatus}" via authorized audit.`, 'info');
  }, [ledger, showToast]);

  const value = useMemo(
    () => ({
      activePage,
      setActivePage,
      pageParam,
      setPageParam,
      navigateTo,
      searchQuery,
      setSearchQuery,
      isSidebarCollapsed,
      setIsSidebarCollapsed,
      isMobileDrawerOpen,
      setIsMobileDrawerOpen,

      // Profile
      profile,
      updateProfile,

      // Crops
      crops,
      addCrop,
      updateCrop,
      deleteCrop,
      addHarvestStock,

      // Market Prices
      marketPrices,
      setMarketPrices,

      // Sales
      sales,
      createSale,

      // Purchases
      purchases,
      addPurchase,

      // Stock
      stockRecords,

      // OTP Confirmations
      otpRequests,
      verifyOTP,
      rejectOTP,
      resendOTP,
      pendingOtpCount,

      // Ledger
      ledger,
      updatePaymentStatus,

      // Notifications
      notifications,
      unreadNotificationsCount,
      markNotificationAsRead,
      markAllNotificationsAsRead,

      // Modals & UI State
      selectedTransaction,
      setSelectedTransaction,
      activeOtpRequest,
      setActiveOtpRequest,
      toast,
      showToast,
      hideToast,
    }),
    [
      activePage,
      pageParam,
      navigateTo,
      searchQuery,
      isSidebarCollapsed,
      isMobileDrawerOpen,
      profile,
      updateProfile,
      crops,
      addCrop,
      updateCrop,
      deleteCrop,
      addHarvestStock,
      marketPrices,
      sales,
      createSale,
      purchases,
      addPurchase,
      stockRecords,
      otpRequests,
      verifyOTP,
      rejectOTP,
      resendOTP,
      pendingOtpCount,
      ledger,
      updatePaymentStatus,
      notifications,
      unreadNotificationsCount,
      markNotificationAsRead,
      markAllNotificationsAsRead,
      selectedTransaction,
      activeOtpRequest,
      toast,
      showToast,
      hideToast,
    ]
  );

  return <FarmerContext.Provider value={value}>{children}</FarmerContext.Provider>;
}

export function useFarmer() {
  const context = useContext(FarmerContext);
  if (!context) {
    throw new Error('useFarmer must be used inside FarmerProvider');
  }
  return context;
}
